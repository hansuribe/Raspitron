import{default as t}from"../components/pages/_layout.svelte-fec15f56.js";export{t as component};
