import{_ as r}from"./_page-8550a910.js";import{default as t}from"../components/pages/ourteam/_page.svelte-c495b1c4.js";export{t as component,r as shared};
