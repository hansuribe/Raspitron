import{_ as r}from"./_page-268e6e04.js";import{default as t}from"../components/pages/_page.svelte-70b254ea.js";export{t as component,r as shared};
