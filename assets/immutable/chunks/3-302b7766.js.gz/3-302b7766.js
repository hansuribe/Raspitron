import{_ as r}from"./_page-031eec46.js";import{default as t}from"../components/pages/about/_page.svelte-0ec1b1b6.js";export{t as component,r as shared};
