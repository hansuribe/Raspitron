import{default as t}from"../components/error.svelte-0d05975e.js";export{t as component};
