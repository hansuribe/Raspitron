import{_ as r}from"./_page-0f790845.js";import{default as t}from"../components/pages/portafolio/_page.svelte-279917bc.js";export{t as component,r as shared};
