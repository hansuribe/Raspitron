import{p}from"../../chunks/_page-268e6e04.js";export{p as prerender};
