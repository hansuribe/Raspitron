import"../../../chunks/environment-3faaec3b.js";import{c as o,p as s}from"../../../chunks/_page-031eec46.js";export{o as csr,s as prerender};
