import"../../../chunks/environment-3faaec3b.js";import{c as o,p as s}from"../../../chunks/_page-8550a910.js";export{o as csr,s as prerender};
