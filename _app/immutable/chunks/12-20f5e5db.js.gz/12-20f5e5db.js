import{default as t}from"../components/pages/signup/_page.svelte-31a9f5e2.js";export{t as component};
