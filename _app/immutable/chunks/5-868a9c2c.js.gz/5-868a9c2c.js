import{_ as e}from"./_page-8cf51044.js";export{e as shared};
