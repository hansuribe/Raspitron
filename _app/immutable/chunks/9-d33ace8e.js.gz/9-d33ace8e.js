import{default as t}from"../components/pages/panel/ecommerce/_page.svelte-f5b624c2.js";export{t as component};
