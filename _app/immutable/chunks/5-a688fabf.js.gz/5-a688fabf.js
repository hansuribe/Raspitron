import{_ as r}from"./_page-29c3c3f0.js";import{default as t}from"../components/pages/portafolio/_page.svelte-2228f6de.js";export{t as component,r as shared};
