const o=""+new URL("../assets/logo-470e047c.svg",import.meta.url).href;export{o as l};
