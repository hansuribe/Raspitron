function t(o){return setTimeout(()=>{o.focus()}),{destroy(){}}}export{t as f};
