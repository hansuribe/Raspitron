import{default as t}from"../components/pages/panel/_...slug_/_page.svelte-cb334dd9.js";export{t as component};
