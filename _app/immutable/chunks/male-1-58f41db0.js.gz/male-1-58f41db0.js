const e=""+new URL("../assets/male-1-b9f79da7.jpeg",import.meta.url).href;export{e as m};
