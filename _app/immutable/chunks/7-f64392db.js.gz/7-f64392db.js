import{default as t}from"../components/pages/logout/_page.svelte-89937286.js";export{t as component};
