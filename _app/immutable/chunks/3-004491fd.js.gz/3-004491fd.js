import{default as t}from"../components/pages/panel/_error.svelte-938dd68a.js";export{t as component};
