import{default as t}from"../components/pages/_layout.svelte-1bdf857b.js";export{t as component};
