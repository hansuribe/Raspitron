import{default as t}from"../components/pages/panel/ecommerce/add/_page.svelte-5d2891cb.js";export{t as component};
