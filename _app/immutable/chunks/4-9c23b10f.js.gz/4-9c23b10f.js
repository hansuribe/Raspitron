import{_ as r}from"./_page-89d186f9.js";import{default as t}from"../components/pages/ourteam/_page.svelte-d89d2bf5.js";export{t as component,r as shared};
