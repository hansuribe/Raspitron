import{_ as r}from"./_layout-1daba58d.js";import{default as t}from"../components/pages/_layout.svelte-d960eb4d.js";export{t as component,r as shared};
