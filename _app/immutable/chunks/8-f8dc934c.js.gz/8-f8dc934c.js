import{default as t}from"../components/pages/panel/dashboard/_page.svelte-83d62afb.js";export{t as component};
