import{default as t}from"../components/pages/_error.svelte-af0e4904.js";export{t as component};
