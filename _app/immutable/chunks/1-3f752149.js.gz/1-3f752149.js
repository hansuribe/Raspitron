import{default as t}from"../components/error.svelte-57927b5c.js";export{t as component};
