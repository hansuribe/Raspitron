import{_ as r}from"./_page-2a465e02.js";import{default as t}from"../components/pages/about/_page.svelte-2cf9f851.js";export{t as component,r as shared};
