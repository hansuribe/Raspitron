import{default as t}from"../components/pages/login/_page.svelte-25ea0588.js";export{t as component};
