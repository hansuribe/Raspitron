import{default as t}from"../components/pages/panel/_layout.svelte-78f7fed8.js";export{t as component};
