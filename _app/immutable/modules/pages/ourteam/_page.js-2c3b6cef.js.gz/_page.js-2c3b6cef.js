import"../../../chunks/environment-b04a8a58.js";import{c as o,p as s}from"../../../chunks/_page-89d186f9.js";export{o as csr,s as prerender};
