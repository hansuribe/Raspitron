import{l}from"../../chunks/_page-8cf51044.js";export{l as load};
