import"../../../chunks/environment-b04a8a58.js";import{c as o,p as s}from"../../../chunks/_page-29c3c3f0.js";export{o as csr,s as prerender};
