import"../../../chunks/environment-2d36df95.js";import{c as o,p as s}from"../../../chunks/_page-929f4120.js";export{o as csr,s as prerender};
