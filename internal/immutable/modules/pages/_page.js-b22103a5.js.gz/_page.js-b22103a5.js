import{p}from"../../chunks/_page-6af8351b.js";export{p as prerender};
