import{_ as r}from"./_page-6af8351b.js";import{default as t}from"../components/pages/_page.svelte-56b30993.js";export{t as component,r as shared};
