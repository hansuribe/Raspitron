import{default as t}from"../components/pages/_layout.svelte-cf98f612.js";export{t as component};
