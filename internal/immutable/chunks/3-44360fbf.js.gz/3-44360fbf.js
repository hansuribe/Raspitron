import{_ as r}from"./_page-82b81fb2.js";import{default as t}from"../components/pages/about/_page.svelte-8d850433.js";export{t as component,r as shared};
