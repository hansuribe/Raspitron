import{_ as r}from"./_page-67349fca.js";import{default as t}from"../components/pages/portafolio/_page.svelte-0db70b7c.js";export{t as component,r as shared};
