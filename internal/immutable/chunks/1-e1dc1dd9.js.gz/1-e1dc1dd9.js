import{default as t}from"../components/error.svelte-22f4484b.js";export{t as component};
