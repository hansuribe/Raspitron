import{_ as r}from"./_page-929f4120.js";import{default as t}from"../components/pages/ourteam/_page.svelte-62bca283.js";export{t as component,r as shared};
