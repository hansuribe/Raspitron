import{p}from"../../../chunks/_page-9da26f2a.js";export{p as prerender};
