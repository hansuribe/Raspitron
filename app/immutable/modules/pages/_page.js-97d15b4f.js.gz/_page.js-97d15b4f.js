import{p}from"../../chunks/_page-02483f10.js";export{p as prerender};
