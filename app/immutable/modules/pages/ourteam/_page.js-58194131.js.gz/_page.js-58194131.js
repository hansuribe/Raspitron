import"../../../chunks/environment-2e81831d.js";import{c as o,p as s}from"../../../chunks/_page-cd7f7323.js";export{o as csr,s as prerender};
