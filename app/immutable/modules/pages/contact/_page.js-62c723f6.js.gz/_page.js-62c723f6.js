import{p}from"../../../chunks/_page-dd42b2ec.js";export{p as prerender};
