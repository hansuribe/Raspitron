import{_ as r}from"./_page-ab98b126.js";import{default as t}from"../components/pages/portafolio/_page.svelte-f012d188.js";export{t as component,r as shared};
