import{_ as r}from"./_page-f30e13d7.js";import{default as t}from"../components/pages/about/_page.svelte-88f0af4f.js";export{t as component,r as shared};
