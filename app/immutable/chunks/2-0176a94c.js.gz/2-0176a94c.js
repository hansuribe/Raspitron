import{_ as r}from"./_page-02483f10.js";import{default as t}from"../components/pages/_page.svelte-74d4cdb5.js";export{t as component,r as shared};
