import{default as t}from"../components/pages/_layout.svelte-91b49ba3.js";export{t as component};
