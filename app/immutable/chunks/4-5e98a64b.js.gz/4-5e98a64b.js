import{_ as r}from"./_page-dd42b2ec.js";import{default as t}from"../components/pages/contact/_page.svelte-b2e3e513.js";export{t as component,r as shared};
