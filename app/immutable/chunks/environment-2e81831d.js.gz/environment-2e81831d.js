const e=!1;export{e as d};
