import{_ as r}from"./_page-cd7f7323.js";import{default as t}from"../components/pages/ourteam/_page.svelte-e896d767.js";export{t as component,r as shared};
